# Statinf
Python library for statistics and causal inference