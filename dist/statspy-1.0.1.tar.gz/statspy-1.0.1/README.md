# Statspy
Python library for econometrics and advanced statistics
